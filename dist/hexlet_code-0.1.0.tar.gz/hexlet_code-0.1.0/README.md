### Hexlet tests and linter status:
[![Actions Status](https://github.com/schahrom/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/schahrom/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/8b5db982a1b7b1000399/maintainability)](https://codeclimate.com/github/schahrom/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/rQZFGRMwMyA5Na2P5SXDqanc0.svg)](https://asciinema.org/a/rQZFGRMwMyA5Na2P5SXDqanc0)

[![asciicast](https://asciinema.org/a/yIOjmzcC0ir3NwfhsYLQSff76.svg)](https://asciinema.org/a/yIOjmzcC0ir3NwfhsYLQSff76)

[![asciicast](https://asciinema.org/a/RzOoUikRlKPzM7w6rDdY0wMwD.svg)](https://asciinema.org/a/RzOoUikRlKPzM7w6rDdY0wMwD)

[![asciicast](https://asciinema.org/a/aZTChY9bS9sxB2UbrnTbqPExD.svg)](https://asciinema.org/a/aZTChY9bS9sxB2UbrnTbqPExD)